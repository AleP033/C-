﻿namespace its31_task05_edicola.Models
{
    public class Rivista
    {
        public int Id { get; set; }
        public string? Nome { get; set; }
        public string? Codice_univoco { get; set; }
        public string? Descrizione { get; set; }
        public int Prezzo { get; set; }
        public string? Categoria { get; set; }
    }
}