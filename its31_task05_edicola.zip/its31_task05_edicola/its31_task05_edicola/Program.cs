using its31_task05_edicola.Models;
using System.Xml.Linq;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddCors();

var app = builder.Build();

#region Endpoint personalizzati

List<Rivista> elenco = new List<Rivista>()
{
    new Rivista(){Id = 1389, Nome = "AlVolante", Codice_univoco = "AB123", Descrizione = "Rivista sulle novit� del mondo automobilistico", Prezzo = 3, Categoria = "Automotive"},
    new Rivista(){Id = 8965, Nome = "National Geographic Magazine", Codice_univoco = "GH675", Descrizione = "Rivista scientifica", Prezzo = 4, Categoria = "Scientifica"},
    new Rivista(){Id = 4567, Nome = "Hacker Journal", Codice_univoco = "MM900", Descrizione = "Rivista sulla difesa dagli attacchi informatici", Prezzo = 5, Categoria = "Cybersecurity"},
};

app.MapGet("/", () => elenco);

app.MapGet("/{varId:int}", (int varId) =>
{
    Rivista? riv = elenco.FirstOrDefault(r => r.Id == varId);
    if (riv is not null)
        return Results.Ok(riv);

    return Results.NotFound();
});

app.MapPost("/", (Rivista riv) =>
{
    if (riv.Nome == "" || riv.Categoria == "")
        return Results.BadRequest();

    riv.Id = elenco.Count + 1;
    elenco.Add(riv);
    return Results.Ok();
});

app.MapDelete("/{varId:int}", (int varId) => {
    Rivista? riv = elenco.FirstOrDefault(r => r.Id == varId);
    if (riv is not null)
    {
        elenco.Remove(riv);
        return Results.Ok();
    }

    return Results.NotFound();
});

app.MapPut("/{varId:int}", (int varId, Rivista rivNew) =>
{
    if (rivNew.Nome == "" || rivNew.Categoria == "")
        return Results.BadRequest();


    Rivista? rivOld = elenco.FirstOrDefault(r => r.Id == varId);
    if (rivOld is null)
        return Results.NotFound();

    if (rivNew.Nome is not null)
        rivOld.Nome = rivNew.Nome;

    if (rivNew.Codice_univoco is not null)
        rivOld.Codice_univoco = rivNew.Codice_univoco;

    if (rivNew.Descrizione is not null)
        rivOld.Descrizione = rivNew.Descrizione;

    if (rivNew.Prezzo != 0)
        rivOld.Prezzo = rivNew.Prezzo;

    if(rivNew.Categoria is not null)
        rivOld.Categoria = rivNew.Categoria;


    return Results.Ok();

});

#endregion

app.UseCors(builder =>
    builder.WithOrigins("*").AllowAnyMethod().AllowAnyHeader()
    );

app.Run();